package com.zeeshan;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class FlightBookingSystemApplicationTests {

	@Test
	public void contextLoads() {
	}

}
