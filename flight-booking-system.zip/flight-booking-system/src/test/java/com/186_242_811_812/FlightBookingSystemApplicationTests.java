package com.zeeshan;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightBookingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
